#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2016 aperpor
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
import scipy.signal as signal
from gnuradio import gr
import pmt
from scipy.ndimage import convolve
import matplotlib.pyplot as plt

class specsense_cc(gr.sync_block):
    """
    Spectrum Sensing block
    Performs the FFT of the received signal, and orders the frequencies from highest to lowest.
    Then, it tries to guess what frequencies are not used with an OFDM carrier, and sends a message to another block with the obtained range.
    """
    def __init__(self,threshold,length,plot):
        gr.sync_block.__init__(self,
            name="specsense_cc",
            in_sig=[numpy.complex64],
            out_sig=None)
	
	# Variable initialization
	self.noiselevel = None
	self.threshold = threshold
	self.length = length
	self.carrierfreqs = 1024/64 * numpy.arange(0,64)
	self.plot = plot
	#self.previousrange = numpy.zeros(length)

	# Message passing
	self.message_port_register_out(pmt.intern('range'))
	self.message_port_register_in(pmt.intern('noiselevel'))
	self.set_msg_handler(pmt.intern('noiselevel'), self.handle_noiselevel)

	# Pyplot stuff
	if self.plot:
	    plt.ion()

    def work(self, input_items, output_items):
        in0 = input_items[0]

	# Signal Processing
	pulse = numpy.ones(self.length) * (1./self.length)
	f, Pxx_den = signal.welch(in0, 64, nfft=1024, scaling="spectrum")
	out = convolve(Pxx_den,pulse,mode="wrap")
	#db = 10*numpy.log10(numpy.abs(fft)**2)
	db = 10*numpy.log(numpy.fft.fftshift(out))
	shiftedf = numpy.fft.fftshift(f)	
	if self.plot:
	    plt.cla()
	    plt.plot(shiftedf,db)
	    plt.ylabel("Power (dB)")
	    plt.xlabel("Frequency (Hz)")
	    plt.ylim(-40,15)

	rango = None
	if self.noiselevel is not None:
	    finalthreshold = 10*numpy.log(self.threshold) + self.noiselevel
	    if self.plot:
		plt.plot(shiftedf,numpy.ones(1024) * finalthreshold,label="Threshold")
		plt.plot(shiftedf,numpy.ones(1024) * self.noiselevel,label="Noise floor")
	    rango = [1 if db[x] < finalthreshold else 0 for x in self.carrierfreqs]
	if self.plot:
	    plt.legend()
	    plt.pause(0.05)
	
	if rango is not None:
	    freecarriers = numpy.where(rango)
	    # Message passing
	    pmt_send = pmt.to_pmt(freecarriers[0].tolist())
	    self.message_port_pub(pmt.intern('range'), pmt_send)

	return len(input_items[0])

    def handle_noiselevel(self, msg_pmt):
	" Updates the noise level so the spectrum sensing can be performed"
	self.noiselevel = pmt.to_python(msg_pmt)

    def set_threshold(self, threshold):
	self.threshold = threshold

    def set_length(self, length):
	self.length = length
