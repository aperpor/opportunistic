#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2016 aperpor
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
from gnuradio import gr
import matplotlib.pyplot as plt
from scipy import signal
import pmt

class noiseest_c(gr.sync_block):
    """
    Noise estimation algorithm from SAR.
    Alpha controls the number of previous samples taken into account.
    Epsilon controls the adaptation speed to huge changes.
    """
    def __init__(self, alpha, epsilon):
        gr.sync_block.__init__(self,
            name="noiseest_c",
            in_sig=[numpy.complex64],
            out_sig=None)
	self.integracio = numpy.zeros(1024)
	self.alpha = alpha
	self.epsilon = epsilon
	self.noiselevel = numpy.ones(1024)
	self.message_port_register_out(pmt.intern('noiselevel'))
	# Was this necessary?
	self.set_output_multiple(512)
	#plt.ion()

    def work(self, input_items, output_items):
        in0 = input_items[0]

	# Signal Processing
	"""
	outr = signal.savgol_filter(in0.real,29,26)
	outi = signal.savgol_filter(in0.imag,29,26)
	out = numpy.array(outr + 1j*outi)
	"""

	f, Pxx_den = signal.welch(in0, nfft=1024,scaling="spectrum")

	#mesura = signal.savgol_filter(Pxx_den,11,6)
	mesura = Pxx_den
	self.integracio = (1-self.alpha)*self.integracio + self.alpha*(mesura)
	self.noiselevel = [x if x < self.noiselevel[i] and x != 0 else (1+self.epsilon)*self.noiselevel[i] if mesura[i] >= self.noiselevel[i] else self.noiselevel[i] for i,x in enumerate(self.integracio)]
	levels = 10*numpy.log(self.noiselevel)
	
	#plt.plot(10*numpy.log(numpy.fft.fftshift(mesura)))
	#plt.pause(0.05)
	# 5dB is the approximate difference between the peak of the pilot
	# carriers and the OFDM symbol.
	pmt_send = pmt.to_pmt(min(levels))
	self.message_port_pub(pmt.intern('noiselevel'), pmt_send)

	# Output
        return len(input_items[0])

    def set_alpha(self, alpha):
	self.alpha = alpha

    def set_epsilon(self, epsilon):
	self.epsilon = epsilon
