#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2017 aperpor
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
import pmt
from gnuradio import gr

class dynallocator_cc(gr.sync_block):
    """
    OFDM Dynamic Carrier Allocator
    Takes the range from the message port, and performs a masking operation to the input. 
    """
    def __init__(self,fft_len):
        gr.sync_block.__init__(self,
            name="dynallocator_cc",
            in_sig=[(numpy.complex64,fft_len)],
            out_sig=[(numpy.complex64,fft_len)])
	# Variable initialization
	self.carriers = None
	self.fft_len = fft_len
	# Message passing
	self.message_port_register_in(pmt.intern('carriers'))
	self.set_msg_handler(pmt.intern('carriers'), self.handle_carriers)

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
	#print "In Length "+str(len(in0))+" and "+str(len(in0[0]))
	#print "Out Length "+str(len(out))+" and "+str(len(out[0]))

        # Processing
	if self.carriers is not None and len(self.carriers) > 0:
	    mask = [x in self.carriers for x in range(self.fft_len)]
	    for number,vector in enumerate(in0):
		out[number] = vector * mask
		#print out[number]
	#out[:] = in0
        return len(output_items[0])

    def handle_carriers(self, carriers):
	self.carriers = pmt.to_python(carriers)
