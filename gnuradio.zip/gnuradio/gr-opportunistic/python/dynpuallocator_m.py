#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2017 aperpor
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
from gnuradio import gr
import time
import random
import pmt

class dynpuallocator_m(gr.sync_block):
    """
    Dynamic Primary User Allocator
    Block for testing purposes
    """
    def __init__(self, length):
        gr.sync_block.__init__(self,
            name="dynpuallocator_m",
            in_sig=None,
            out_sig=None)
	self.carriers1 = range(5,12) + range(19,31) + range(33,59)
	self.carriers2 = range(5,31) + range(33,48) + range(54,59)
	self.message_port_register_out(pmt.intern('range'))

    def work(self, input_items, output_items):
	
	if(random.randint(0,10)>5):
	    pmt_send = pmt.to_pmt(self.carriers1)
	else:
	    pmt_semd = pmt.to_pmt(self.carriers2)
	self.message_port_pub(pmt.intern('range'), pmt_send)
        
        return len(output_items[0])

